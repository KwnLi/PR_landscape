The LANDFIRE Insular Areas have a restricted set of products available due to limited availability of input data and imagery.

The LANDFIRE product file name includes the following information:
(using LANDFIRE 2016 Remap of Guam EVC as an example)

Program     Extent     Year     Layer     Version
L           G          16       EVC       200 

Program = LANDFIRE [L]

Extent =  American Samoa (z81)             [S]
          Guam, Commonwealth of Northern 
          Mariana Islands (z82)            [G]
          Marshall Islands - East (z88)    [M]
          Marshall Islands - West (z89)    [R]
          Micronesia - Yap (z83)           [Y]
          Micronesia - Chuuk (z84)         [U]
          Micronesia - Pohnpei (z85)       [N]
          Micronesia - Kosrae (z86)        [K]
          Palau (z87)                      [P]
          Puerto Rico, 
          US Virgin Islands (z90)          [V]

Year = last two digits of circa year for product 20[16]

Product = the name of the LANDFIRE Product, [BPS]

Version = LANDFIRE version. 
          105 (1.0.5) = LF 2001 
          200 (2.0.0) = LANDFIRE Remap
          210 (2.1.0) = LANDFIRE Remap Update 1      
      
Attribute Tables (CSV and DBF format) apply to all extents (unless noted)
[F] is applied [LF16_EVC_200]

